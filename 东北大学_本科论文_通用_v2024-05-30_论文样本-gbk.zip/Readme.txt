english: 
	"gbk" occurs in the zipfile name, please unzip this zipfile with gbk(or Gbk GBK) coding:
	 		a) use below command in your console shell:
	 			unzip -O gbk gbk--xxxx.zip
	 		b) or set your uncompress software to decode this file with gbk
		    c) for windows 10 and above, user can open the zipped file directly in file manager 
	 "utf8" occurs in the zipfile name, please unzip this zipfile with utf8 (or utf-8) codeing:
	 		a) use below command in your console shell:
	 			unzip  -O utf8 utf8--xxxx.zip
	 		b) set your uncompress software to decoding this file with utf8
    
中文说明:
     文件名带gbk的压缩文件解压, 为保持文件名称不乱码，务必使用Gbk编码解压缩本文件:
	 		a) 使用如下解压命令：
	 		    unzip -O Gbk Gbk--xxxx.zip
	 		b) 或者设置你所使用的解压软件的编码格式为gbk(或者：Gbk GBK)
			c) 在 windows 下直接使用文件管理器可直接打开(自动解压)
    文件名带utf8的压缩文件解压, 为保持文件名称不乱码，务必使用utf8编码解压缩本文件:
	 		a) 使用如下解压命令：
	 		unzip -O utf8 utf8--xxxx.zip
	 		b) 或者设置你所使用的解压软件的编码格式为utf8

	 